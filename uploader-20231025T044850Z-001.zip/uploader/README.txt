TikTok Mass Uploader

--- About ---
This program can post content on many accounts via their sessionID.
Slideshow and Videos are supported and there is a simple way to use content.


-- File Structure --
Depending on what you want to post there is a content folder, insider there is "slideshows" and "videos"

content
├───slideshows
│   └───1
└───videos
    ├───1
    └───2
data
├─── proxies.txt  | A list of http proxies (seperated by new lines)
└─── sessions.txt | A list of sessionIDs   (seperated by new lines)

Inside each post you want to make you put either your images or video file.

- Create audios.txt and make a list of TikTok Audio ids seperated by new lines. This is usefull for posting
  the same content with different audios, a new audio is chosed on each account (unless only 1 audio is listed)

- Create descriptions.txt and write descriptions for videos/slideshows, if you @mention a tiktok user, the program
  will convert that to a proper mention in the description


-- Configuration --
As you can see there are quite a few controls giving you everything needed to test and schedule posts.

<--- In this current config I have made it so the program will post content from both types.

private_mode: If true, it will post to the accounts privately.

shuffle_posts: This toggles wether to go in order from 1 and higher, or to grab a random folder from one of
		your content selections

number_of_posts: This number defines how many total posts you want per account, if set to 6 it will split
		the number of videos and slideshows. 0 = everything

schedule: This allows you to run the program and let it post to accounts on a schedule you define, this is great 	  for automated posting without too much effort, when "enabled" is false, it will skip the schedule
	  allowing you to post right as the program is ran, mainly for testing or on the fly uploads