import asyncio
from datetime import datetime, timezone
import logging
import aiohttp
from rocketry import Rocketry

from uploader.utils.internal import load_config, upload_content

from uploader.utils.logging import logger

app = Rocketry(execution="async")

session: aiohttp.ClientSession = None


@app.task("every 1 minute")
async def check_and_upload():
    global session
    config = load_config()

    now = datetime.now(timezone.utc)

    today = now.strftime("%A").lower()

    for time_data in config.schedule.when:
        day = time_data["day"].lower()
        time = time_data["time"]
        if day == today and time == now.strftime("%H:%M"):
            await upload_content(session)


async def main():
    global session
    config = load_config()
    logger.setLevel(config.log_level.upper())
    timeout = aiohttp.ClientTimeout(total=30)
    session = aiohttp.ClientSession(timeout=timeout)

    if not config.schedule.enabled:
        logger.info("Skipping wait")
        await upload_content(session)
        await session.close()
        exit(0)
    else:
        logger.info("Waiting for scheduled time")

    rocketry_task = asyncio.create_task(app.serve())

    try:
        await rocketry_task
    except asyncio.CancelledError:
        await session.close()
        rocketry_task.cancel()
        exit(0)


if __name__ == "__main__":
    asyncio.run(main())
