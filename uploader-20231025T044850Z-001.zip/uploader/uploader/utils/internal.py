import os
import random
from time import time
from typing import List

import aiohttp
from uploader.models import Config, Content
import json
from random import choice, randrange

from uploader.models.configs import Slideshow, Video
from uploader.models.tiktok import AwemeTypes
from uploader.utils import create_aweme, upload_images, upload_video
from uploader.utils.logging import logger

__all__ = (
    "upload_content",
    "load_config",
)


def load_config(config_path: str = "./data/config.json") -> Config:
    """Load the config file and return the config object"""

    # create the following folder if they don't exist
    folder = ["./data", "./content", "./content/slideshows", "./content/videos"]

    for f in folder:
        if not os.path.exists(f):
            os.mkdir(f)

    with open(config_path, "r") as f:
        config = json.load(f)

    return Config(**config)


# logger.debug()
def load_content() -> Content:
    """Load the content from the content folder"""

    logger.info("Loading content...")

    config = load_config()
    content_folder = "./content"
    content = Content()
    if not os.path.exists(content_folder):
        logger.debug("Content folder not found: %s", content_folder)
        raise FileNotFoundError("Content folder not found")

    if config.do_slideshow_posts:
        logger.debug("Loading slideshow posts...")

        slideshows_folder = os.path.join(content_folder, "slideshows")
        if os.path.exists(slideshows_folder):
            slideshow_list = []
            slideshow_folders = os.listdir(slideshows_folder)
            if config.shuffle_posts:
                random.shuffle(slideshow_folders)
                logger.debug("Shuffling slideshows...")
            for slideshow_name in slideshow_folders:
                slideshow_path = os.path.join(slideshows_folder, slideshow_name)
                if os.path.isdir(slideshow_path):
                    logger.debug("Loading slideshow: %s", slideshow_name)

                    with open(
                        os.path.join(slideshow_path, "audios.txt"), "r"
                    ) as audio_file:
                        audio_ids = audio_file.read().splitlines()

                    with open(
                        os.path.join(slideshow_path, "descriptions.txt"), "r"
                    ) as description_file:
                        descriptions = description_file.read().splitlines()

                    if len(audio_ids) == 0:
                        audio_ids = [""]
                    if len(descriptions) == 0:
                        descriptions = [""]

                    supported_files = [".png", ".jpg", ".jpeg", ".webp"]
                    image_files = [
                        f
                        for f in os.listdir(slideshow_path)
                        if f.lower().endswith(tuple(supported_files))
                    ]
                    image_paths = [
                        os.path.join(slideshow_path, img).replace("\\", "/")
                        for img in image_files
                    ]

                    slideshow = Slideshow(
                        audio_id=choice(audio_ids) if config.use_random_audio else "",
                        description=choice(descriptions),
                        images=image_paths,
                    )
                    slideshow_list.append(slideshow)

            content.slideshows = slideshow_list

    if config.do_video_posts:
        logger.debug("Loading video posts...")

        videos_folder = os.path.join(content_folder, "videos")
        if os.path.exists(videos_folder):
            video_list = []
            video_folders = os.listdir(videos_folder)
            if config.shuffle_posts:
                random.shuffle(video_folders)
                logger.debug("Shuffling videos...")
            for video_name in video_folders:
                video_path = os.path.join(videos_folder, video_name)
                if os.path.isdir(video_path):
                    logger.debug("Loading video: %s", video_name)

                    with open(
                        os.path.join(video_path, "audios.txt"), "r"
                    ) as audio_file:
                        audio_ids = audio_file.read().splitlines()

                    with open(
                        os.path.join(video_path, "descriptions.txt"), "r"
                    ) as description_file:
                        descriptions = description_file.read().splitlines()

                    if len(audio_ids) == 0:
                        audio_ids = [""]
                    if len(descriptions) == 0:
                        descriptions = [""]

                    video_files = [
                        f for f in os.listdir(video_path) if f.endswith(".mp4")
                    ]
                    video_paths = [
                        os.path.join(video_path, vid).replace("\\", "/")
                        for vid in video_files
                    ]

                    if len(video_paths) > 1:
                        video_paths = [choice(video_paths)]

                    video = Video(
                        audio_id=choice(audio_ids) if config.use_random_audio else "",
                        description=choice(descriptions),
                        video=video_paths[0] if video_paths else "",
                    )
                    video_list.append(video)

            content.videos = video_list

    if (
        config.number_of_posts != 0
        and config.do_slideshow_posts
        and config.do_video_posts
    ):
        logger.debug("Distributing content for both slideshows and videos...")

        total_slideshows = len(content.slideshows)
        total_videos = len(content.videos)
        total_content = total_slideshows + total_videos

        num_slideshows = (config.number_of_posts * total_slideshows) // total_content
        num_videos = config.number_of_posts - num_slideshows

        selected_slideshows = random.sample(content.slideshows, num_slideshows)
        selected_videos = random.sample(content.videos, num_videos)

        content.slideshows = selected_slideshows
        content.videos = selected_videos

    elif config.number_of_posts != 0 and config.do_slideshow_posts:
        logger.debug("Distributing content for slideshows...")

        sample_size = min(config.number_of_posts, len(content.slideshows))
        content.slideshows = random.sample(content.slideshows, sample_size)

    elif config.number_of_posts != 0 and config.do_video_posts:
        logger.debug("Distributing content for videos...")

        sample_size = min(config.number_of_posts, len(content.videos))
        content.videos = random.sample(content.videos, sample_size)

    logger.info("Content loaded successfully.")
    logger.debug(f"{len(content.slideshows)} slideshows")
    logger.debug(f"{len(content.videos)} videos")
    return content


def load_session_ids() -> List[str]:
    """Load the session IDs from the session_ids.txt file"""

    logger.info("Loading session IDs...")

    session_ids = []
    try:
        with open("./data/sessions.txt", "r") as f:
            session_ids = f.read().splitlines()
            logger.debug(f"Session IDs loaded: {len(session_ids)}")
    except FileNotFoundError:
        logger.exception("Session IDs file not found. Place it in ./data/sessions.txt")
        exit(1)
    logger.info("Session IDs loaded successfully.")
    return session_ids


async def upload_content(session: aiohttp.ClientSession):
    """Upload the content to Instagram"""
    content = load_content()
    session_ids = load_session_ids()
    config = load_config()

    for session_id in session_ids:
        logger.info(f"Uploading with session ID: {session_id}")

        try:
            # Upload slideshows
            for i, slideshow in enumerate(content.slideshows):
                logger.debug(f"Uploading slideshow: {slideshow}")

                try:
                    logger.info(
                        f"Uploading slideshow {i+1} of {len(content.slideshows)}"
                    )
                    image_commit_data = await upload_images(
                        images=slideshow.images,
                        session_id=session_id,
                        aioss=session,
                    )
                    logger.debug(
                        f"Uploaded slideshow {i+1} of {len(content.slideshows)}"
                    )

                    logger.debug(
                        f"Posting slideshow {i+1} of {len(content.slideshows)} to tiktok"
                    )
                    await create_aweme(
                        aweme_type=AwemeTypes.SLIDESHOW,
                        commit_data=image_commit_data,
                        description=slideshow.description,
                        music_id=slideshow.audio_id,
                        session_id=session_id,
                        private=config.private_mode,
                        aioss=session,
                    )
                    logger.info(
                        f"Posted slideshow {i+1} of {len(content.slideshows)} successfully!"
                    )
                except Exception as e:
                    logger.exception(f"Error uploading slideshow: {e}")
                    raise e

            # Upload videos
            for i, video in enumerate(content.videos):
                logger.debug(f"Uploading video: {video}")

                try:
                    logger.info(f"Uploading video {i+1} of {len(content.videos)}")
                    video_commit_data = await upload_video(
                        video=video.video,
                        session_id=session_id,
                        music_id=video.audio_id,
                        aioss=session,
                    )
                    logger.debug(f"Uploaded video {i+1} of {len(content.videos)}")

                    logger.debug(
                        f"Posting video {i+1} of {len(content.videos)} to tiktok"
                    )
                    await create_aweme(
                        aweme_type=AwemeTypes.VIDEO,
                        commit_data=video_commit_data,
                        description=video.description,
                        music_id=video.audio_id,
                        session_id=session_id,
                        private=config.private_mode,
                        aioss=session,
                    )
                    logger.info(
                        f"Posted video {i+1} of {len(content.videos)} successfully!"
                    )
                except Exception as e:
                    logger.error(f"Error uploading video: {e}")

        except Exception as e:
            logger.error(f"Error uploading content with session ID {session_id}: {e}")
