import asyncio
from datetime import datetime, timezone
import json
import os
from random import choice, choices
import re
from time import time, time_ns
from types import NoneType
from typing import List, Tuple
from urllib.parse import urlencode
import uuid
from zlib import crc32
from pydantic import ValidationError
from uploader.models.tiktok import AwemeTypes
from uploader.utils import sign_request, create_auth_header
from uploader.models import PassportAccountInfo, UploadAuthKeys, UploadResponse
from uploader.utils.logging import logger


import aiohttp


__all__ = (
    "fetch_self_info",
    "fetch_upload_keys",
    "upload_action",
    "upload_file",
    "create_aweme",
    "upload_images",
    "upload_video",
    "format_description",
    "get_random_proxy",
)


def get_random_proxy() -> str:
    with open("./data/proxies.txt", "r") as f:
        proxies = f.read().splitlines()
    if len(proxies) == 0:
        return ""
    return choice(proxies)


async def fetch_self_info(
    session_id: str, *, aioss: aiohttp.ClientSession
) -> PassportAccountInfo:
    url = "https://api16-normal-useast5.us.tiktokv.com/passport/account/info/v2/"

    signed = sign_request(
        url=url,
        cookies=[f"sessionid={session_id}"],
    )

    async with aioss.get(
        signed.url,
        headers=signed.headers,
        proxy=get_random_proxy(),
    ) as resp:
        data = await resp.json()

    try:
        acc_info = PassportAccountInfo(**data["data"])
        print(acc_info)
    except ValidationError:
        raise ValueError("Invalid session_id")

    return acc_info


async def fetch_upload_keys(
    session_id: str, *, aioss: aiohttp.ClientSession
) -> UploadAuthKeys:
    url = "https://api16-core-useast5.us.tiktokv.com/aweme/v1/upload/authkey/"

    signed = sign_request(
        url=url,
        cookies=[f"sessionid={session_id}"],
    )

    async with aioss.get(
        signed.url,
        headers=signed.headers,
        proxy=get_random_proxy(),
    ) as resp:
        data = await resp.json()

    try:
        keys = UploadAuthKeys(**data)
    except ValidationError:
        raise ValueError("Error fetching upload keys")

    return keys


async def upload_action(
    host: str,
    *,
    session: aiohttp.ClientSession,
    method: str,
    access_key_id: str,
    access_key_secret: str,
    amz_security_token: str,
    service_name: str,
    params: dict,
    payload: dict = None,
) -> UploadResponse:
    """
    This function allows you to interact with file upload endpoints
    """
    t = datetime.now(tz=timezone.utc)

    if payload:
        payload = json.dumps(payload, separators=(",", ":"))
    else:
        payload = ""

    url = f"https://{host}/top/v1"

    logger.debug(f"UploadAction - {params['Action']} {url[8:]} {method}")
    amz_headers = create_auth_header(
        url=url,
        method=method,
        access_key_id=access_key_id,
        access_key_secret=access_key_secret,
        amz_security_token=amz_security_token,
        service=service_name,
        params=params,
        date=t,
        payload=payload,
    )

    headers = {
        "user-agent": f"BDFileUpload({time_ns()})",
        **amz_headers,
    }

    async with session.request(
        method=method,
        url=url,
        headers=headers,
        params=params,
        data=payload,
    ) as resp:
        data = await resp.json()

    try:
        response = UploadResponse(**data)
    except ValidationError as e:
        logger.error(
            f"Error validating upload response: {e}\n(Saved to upload_response.json)"
        )
        with open("upload_response.json", "w") as f:
            f.write(json.dumps(data, indent=4))
        raise e

    return response


async def upload_chunk(
    url: str,
    params: dict,
    headers: dict,
    chunk: bytes,
    retry: bool = True,
    *,
    aioss: aiohttp.ClientSession,
) -> dict:
    retry_attempts = 1 if retry else 0
    while retry_attempts >= 0:
        try:
            async with aioss.post(
                url=url,
                params=params,
                headers=headers,
                data=chunk,
                proxy=get_random_proxy(),
            ) as resp:
                data = await resp.json()
                if message := data.get("message"):
                    if message != "Success":
                        logger.error(
                            f"Error uploading part {params['part_number'] + 1}: {message}"
                        )
                        raise ValueError(message)
                else:
                    logger.error(
                        f"Error uploading part {params['part_number'] + 1}: Unknown error"
                    )
                    raise ValueError("Error uploading file")
                return data
        except Exception as e:
            logger.error(f"Error uploading part {params['part_number'] + 1}: {e}")
            if retry_attempts > 0:
                logger.debug(
                    f"Retrying upload of part {params['part_number'] + 1} ({retry_attempts} retries left)"
                )
                retry_attempts -= 1
                await asyncio.sleep(1)  # Adding a delay before retrying
            else:
                raise


async def upload_file(
    *,
    host: str,
    uploadid: str = None,
    store_uri: str,
    space_key: str,
    file_path: str,
    aioss: aiohttp.ClientSession,
) -> dict:
    if not uploadid:
        uploadid = str(uuid.uuid4())

    url = f"https://{host}/upload/v1/{store_uri}"

    file_bytes = open(file_path, "rb").read()

    chunk_size = 3000000  # 3MB
    chunks = [
        file_bytes[i : i + chunk_size] for i in range(0, len(file_bytes), chunk_size)
    ]
    crc_hashes = [crc32(chunk) for chunk in chunks]

    tasks = []
    for i, (chunk, crc_hash) in enumerate(zip(chunks, crc_hashes)):
        params = {
            "uploadid": uploadid,
            "part_number": i,
            "phase": "transfer",
            "part_offset": i * chunk_size,
        }

        headers = {
            "authorization": space_key,
            "user-agent": f"BDFileUpload({time_ns()})",
            "x-upload-content-crc32": f"{crc_hash:08x}",
        }

        logger.debug(f"Queuing upload of part {i+1}/{len(chunks)}")
        tasks.append(upload_chunk(url, params, headers, chunk, aioss=aioss))

    await asyncio.gather(*tasks)

    logger.debug("Merging uploaded parts")
    headers = {
        "authorization": space_key,
        "user-agent": f"BDFileUpload({time()})",
        "x-bd-merge-start": f"{time_ns()}",
        "x-bd-upload-end": f"{time_ns()}",
        "x-bd-upload-start": f"{time_ns()}",
    }

    params = {
        "uploadmode": "part",
        "phase": "finish",
        "uploadid": uploadid,
    }

    data = ",".join([f"{i}:{crc_hash:08x}" for i, crc_hash in enumerate(crc_hashes)])

    async with aioss.post(
        url=url,
        params=params,
        headers=headers,
        data=data,
        proxy=get_random_proxy(),
    ) as resp:
        data = await resp.json()
        return data


async def fetch_user_ids(username: str, aioss: aiohttp.ClientSession):
    url = "https://api16-normal-useast5.us.tiktokv.com/aweme/v1/user/uniqueid/"

    params = {
        "id": username,
    }

    signed = sign_request(
        url=url,
        params=params,
    )

    async with aioss.get(
        signed.url,
        headers=signed.headers,
        proxy=get_random_proxy(),
    ) as resp:
        data = await resp.json()

    return data


async def format_description(description: str) -> Tuple[str, List[dict]]:
    hashtags = re.findall(r"#\w+", description)
    usernames = re.findall(r"@[\w\d]+", description)

    formatted_description = description
    text_extra = []

    async with aiohttp.ClientSession() as session:
        for hashtag in hashtags:
            formatted_hashtag = f'<h id="{len(text_extra)}">{hashtag}</h>'
            formatted_description = formatted_description.replace(
                hashtag, formatted_hashtag, 1
            )

            text_extra.append(
                {
                    "end": 0,
                    "hashtag_name": hashtag[1:],
                    "isDuet": False,
                    "is_preset": False,
                    "isStarAtlasTag": False,
                    "isTransient": False,
                    "line_idx": 0,
                    "start": 0,
                    "sub_type": 0,
                    "tag_id": str(len(text_extra)),
                    "type": 1,
                }
            )

        for username in usernames:
            user_id_data = await fetch_user_ids(username[1:], session)
            user_id = user_id_data.get("uid", "")
            sec_uid = user_id_data.get("sec_uid", "")

            if user_id:
                formatted_username = f'<m id="{len(text_extra)}">{username}</m>'
                formatted_description = formatted_description.replace(
                    username, formatted_username, 1
                )

                text_extra.append(
                    {
                        "at_user_type": "",
                        "end": 0,
                        "isDuet": False,
                        "is_preset": False,
                        "isStarAtlasTag": False,
                        "isTransient": False,
                        "line_idx": 0,
                        "sec_uid": sec_uid,
                        "start": 0,
                        "sub_type": 0,
                        "tag_id": str(len(text_extra)),
                        "type": 0,
                        "user_id": user_id,
                    }
                )

    return formatted_description, text_extra


async def fetch_music_info(music_id: str, *, aioss: aiohttp.ClientSession) -> dict:
    url = "https://api16-normal-useast5.us.tiktokv.com/aweme/v1/music/detail/"

    params = {
        "music_id": music_id,
    }

    signed = sign_request(
        url=url,
        params=params,
    )

    async with aioss.get(
        signed.url,
        headers=signed.headers,
        proxy=get_random_proxy(),
    ) as resp:
        data = await resp.json()

    return data.get("music_info", {})


async def generate_aweme_config(
    aweme_type: AwemeTypes,
    commit_data: UploadResponse,
    *,
    title: str = None,
    description: str = None,
    music_id: str = None,
    private: bool = False,
    mature: bool = False,
    music_volume: int = 100,
    origin_volume: int = 0,
    mention_users: List[str] = [],
    aioss: aiohttp.ClientSession,
) -> str:
    # NOTE: This is the data shared between all aweme types
    aweme_data = {
        "new_sdk": 1,
        "mixed_type": 0,
        "retry_type": 0,
        "is_diy_prop": 0,
        "remove_background": 0,
        "is_text_reading": 0,
        "video_width": 0,
        "video_height": 0,
        "video_cover_uri": "",
        "video_cnt": 1,
        "tag_uid_list": mention_users,
        "pic_cnt": 0,
        "is_multi_content": 0,
        "music_id": music_id or "",
        "enable_auto_caption": "-1",
        "selected_asr_lang": "en",
        "has_original_audio": 0,
        "original": 0,
        "is_editor_pro_used": 0,
        "is_pic_in_pic_used": 0,
        "all_editor_pro_used_functions": "",
        "tab_name": "",
        "content_type": "video",
        "creation_id": str(uuid.uuid4()),
        "tts_voice_has_creator": 0,
        "camera": 0,
        "prettify": 0,
        "author": "Original Sound",
        "title": "Original Sound",
        "is_upload_audio_track": "false",
        "is_multi_video_upload": "false",
        "use_camera_type": 1,
        "h264_high_profile": 1,
        "camera_compat_level": 0,
        "import_video_info": [{"h": 1920, "w": 1080, "b": 21043, "e": 28}],
        "music_begin_time": 0,
        "music_end_time": "7266",
        "music_selected_from": "edit_page_recommend",
        "is_draft": 0,
        "initial_privacy_status": "private" if private else "public",
        "is_default_prop": 0,
        "interact_sticker_check": 0,
        "ibe_status_monitor": 0,
        "is_commercial_sound_page": 0,
        "is_star_atlas": 0,
        "branded_content_type": 0,
        "is_dubbed": 0,
        "cover_tsp": "0.0",
        "follow_up_publish_from_id": "-1",
        "follow_up_first_item_id": "",
        "follow_up_item_id_groups": [],
        "countdown_list": [],
        "is_music_looped": 0,
        "text_fonts": "",
        "text_font_effect_ids": "",
        "is_subtitled": 0,
        "has_text": 0,
        "caption_word_cnt": "67",
        "filter_value": "-1.0",
        "is_original_filter": 1,
        "beautify_info": "",
        "beautify_used": 1,
        "is_composer": 1,
        "fast_import": 1,
        "music_volume": music_volume,
        "origin_volume": origin_volume,
        "is_trimmed": 0,
        "is_long_video": 0,
        "allow_adding_to_story": 1,
        "is_tiktok_story": 0,
        "now_media_type": "post",
        "now_post_by": 0,
        "use_original_ugc_template": 0,
        "open_platform_extra": "",
        "open_platform_key": "",
        "encode_hdr_type": 0,
        "markup_text": "",
        "is_private": int(private),
        "is_hash_tag": 1,
        "shoot_way": "direct_shoot",
        "is_hard_code": "10",
        "file_fps": "30",
        "item_comment": 0,
        "open_platform_auto_sync": [],
        "item_react": 0,
        "item_duet": 0,
        "item_stitch": 0,
        "geofencing_regions": [],
        "anchors": [],
        "text_added": 0,
        "has_original_vframe": "2",
        "mature_theme_type": int(mature),
        "allow_create_sticker": "2",
        "post_trends_type": 0,
        "post_trends_id": "",
        "studio_content_filter_type": 0,
        "duration": "7.266",
        "is_sub_only_video": 0,
        "pre_check_music_copyright": 0,
    }

    description, text_extra = await format_description(description)

    aweme_data["text_extra"] = text_extra
    aweme_data["markup_text"] = description

    if music_id:
        music_info = await fetch_music_info(music_id, aioss=aioss)
        music_author = music_info.get("author", "")
        music_title = music_info.get("album", "")
        aweme_data["author"] = music_author
        aweme_data["title"] = music_title

    if aweme_type == AwemeTypes.SLIDESHOW:
        aweme_data["creation_id"] = str(uuid.uuid4())
        aweme_data["video_id"] = ""
        aweme_data["duration"] = "0.000"
        aweme_data["file_fps"] = "0"
        aweme_data["image_content_type"] = "4"
        aweme_data["music_volume"] = "200"
        aweme_data["caption_word_cnt"] = "0"
        aweme_data["aweme_type"] = "150"
        aweme_data["music_type"] = "1"
        aweme_data["video_cover_uri"] = None
        aweme_data["video_cnt"] = 0
        aweme_data["pic_cnt"] = len(commit_data.Result.Results)
        aweme_data["content_type"] = "multi_photo"
        aweme_data["misc_info"] = {
            "green_screen": 0,
            "koi_fish": 0,
            "video_tag": 0,
            "mv_template_type": 0,
            "source_id": 1,
        }

        _images = [
            {
                "height_px": x.ImageHeight,
                "uri": x.ImageUri,
                "width_px": x.ImageWidth,
            }
            for x in commit_data.Result.PluginResult
        ]

        aweme_data["image_post_content"] = {
            "cover": _images[0],
            "images": _images,
            "music_volume": 1.0,
            "title": "",
        }

        aweme_data["import_video_info"] = [
            {
                "h": x.ImageHeight,
                "w": x.ImageWidth,
                "b": 0,
                "e": 0,
            }
            for x in commit_data.Result.PluginResult
        ]

    if aweme_type == AwemeTypes.VIDEO:
        aweme_data["creation_id"] = str(uuid.uuid4())
        aweme_data["video_id"] = commit_data.Result.Results[0].Vid
        aweme_data["video_cnt"] = 1
        aweme_data["pic_cnt"] = 0
        aweme_data["content_type"] = "video"
        aweme_data["import_video_info"] = [
            {
                "h": commit_data.Result.Results[0].VideoMeta.Height,
                "w": commit_data.Result.Results[0].VideoMeta.Width,
                "b": 21043,
                "e": 28,
            }
        ]

        aweme_data["music_end_time"] = int(
            commit_data.Result.Results[0].VideoMeta.Duration * 1000
        )
        aweme_data["music_selected_from"] = "edit_page_recommend"
        aweme_data["music_show_rank"] = 0
        aweme_data["music_rec_type"] = 0
        aweme_data["interaction_stickers"] = []
        aweme_data["info_sticker"] = ""
        aweme_data["fast_import"] = 1
        aweme_data["duration"] = commit_data.Result.Results[0].VideoMeta.Duration
        aweme_data["segment_count"] = 1
        aweme_data["segment_durations"] = commit_data.Result.Results[
            0
        ].VideoMeta.Duration

    for key, value in aweme_data.items():
        if isinstance(value, NoneType):
            aweme_data[key] = ""

        if isinstance(value, dict):
            # dont add spaces
            aweme_data[key] = json.dumps(value, separators=(",", ":"))

        if isinstance(value, list):
            aweme_data[key] = json.dumps(value, separators=(",", ":"))

    return urlencode(aweme_data)


async def create_aweme(
    aweme_type: AwemeTypes,
    commit_data: UploadResponse,
    *,
    description: str = None,
    music_id: str = None,
    private: bool = False,
    mature: bool = False,
    mention_users: List[str] = None,
    session_id: str,
    music_volume: int = 100,
    origin_volume: int = 0,
    aioss: aiohttp.ClientSession,
) -> dict:
    url = "https://api16-core-useast5.us.tiktokv.com/aweme/v1/create/aweme/"

    aweme_config = await generate_aweme_config(
        aweme_type=aweme_type,
        commit_data=commit_data,
        description=description,
        music_id=music_id,
        private=private,
        mature=mature,
        mention_users=mention_users,
        music_volume=music_volume,
        origin_volume=origin_volume,
        aioss=aioss,
    )

    headers = {
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
    }

    signed = sign_request(
        url=url,
        cookies=[f"sessionid={session_id}"],
        payload=aweme_config,
        add_headers=headers,
    )

    async with aioss.post(
        signed.url,
        headers=signed.headers,
        data=aweme_config,
        proxy=get_random_proxy(),
    ) as resp:
        return await resp.json()


async def upload_images(
    *,
    images: List[str],
    session_id: str,
    aioss: aiohttp.ClientSession,
) -> UploadResponse:
    keys = await fetch_upload_keys(session_id, aioss=aioss)
    info = await fetch_self_info(session_id, aioss=aioss)

    init_image_upload = await upload_action(
        host=keys.photo_upload_config.imageHostName,
        method="GET",
        service_name="imagex",
        access_key_id=keys.photo_upload_config.authorization2.access_key_id,
        access_key_secret=keys.photo_upload_config.authorization2.secret_access_key,
        amz_security_token=keys.photo_upload_config.authorization2.session_token,
        params={
            "Action": "ApplyImageUpload",
            "FileType": "image",
            "ServiceId": "photomode",
            "UploadNum": len(images),
            "Version": "2018-08-01",
            "appid": "1233",
            "device_platform": "android",
            "did": "7237206354237310506",
            "net_type": "wifi",
            "uid": info.user_id_str,
            "update_version_code": "2022902030",
            "version_code": "2022902030",
        },
        session=aioss,
    )
    upload_host = init_image_upload.Result.UploadAddress.UploadHosts[0]
    for i, store_info in enumerate(init_image_upload.Result.UploadAddress.StoreInfos):
        await upload_file(
            host=upload_host,
            store_uri=store_info.StoreUri,
            space_key=store_info.Auth,
            uploadid=store_info.UploadID,
            file_path=images[i],
            aioss=aioss,
        )

    commit_image_upload = await upload_action(
        host=keys.photo_upload_config.imageHostName,
        method="POST",
        access_key_id=keys.photo_upload_config.authorization2.access_key_id,
        access_key_secret=keys.photo_upload_config.authorization2.secret_access_key,
        amz_security_token=keys.photo_upload_config.authorization2.session_token,
        service_name="imagex",
        params={
            "Action": "CommitImageUpload",
            "ServiceId": "photomode",
            "Version": "2018-08-01",
            "appid": "1233",
            "device_platform": "android",
            "did": "7237206354237310506",
            "net_type": "wifi",
            "uid": info.user_id_str,
            "update_version_code": "2022902030",
            "version_code": "2022902030",
        },
        payload={
            "Function": None,
            "SessionKey": init_image_upload.Result.UploadAddress.SessionKey,
        },
        session=aioss,
    )

    return commit_image_upload


async def replace_video_audio(
    video_path: str, music_id: str, aioss: aiohttp.ClientSession
) -> str:
    # create folder ./tmp
    if not os.path.exists("./tmp"):
        os.mkdir("./tmp")

    # fetch the music info
    music_info = await fetch_music_info(music_id, aioss=aioss)

    # download the music from mp3
    music_url: str = music_info.get("play_url", {}).get("uri", None)

    if not music_url:
        logger.error("Error fetching music id")
        return None

    # download the music
    music_resp = await aioss.get(music_url)

    with open(f"./tmp/{music_id}.mp3", "wb") as f:
        f.write(await music_resp.read())

    import ffmpeg

    video_file = ffmpeg.input(video_path)
    audio_file = ffmpeg.input(f"./tmp/{music_id}.mp3")

    merge_audio = (
        ffmpeg.output(
            audio_file,
            video_file,
            f"./tmp/{music_id}.mp4",
            shortest=None,
            loglevel="error",
        )
        .overwrite_output()
        .run()
    )

    # delete the music file
    os.remove(f"./tmp/{music_id}.mp3")

    return f"./tmp/{music_id}.mp4"


async def upload_video(
    *,
    video: str,
    session_id: str,
    music_id: str = None,
    aioss: aiohttp.ClientSession,
) -> UploadResponse:
    keys = await fetch_upload_keys(session_id, aioss=aioss)
    info = await fetch_self_info(session_id, aioss=aioss)

    init_video_upload = await upload_action(
        host=keys.video_config.videoHostName,
        method="GET",
        service_name="vod",
        access_key_id=keys.video_config.authorization2.access_key_id,
        access_key_secret=keys.video_config.authorization2.secret_access_key,
        amz_security_token=keys.video_config.authorization2.session_token,
        params={
            "Action": "ApplyUploadInner",
            "Region": "US",
            "SpaceName": "musical.ly",
            "StoreRegion": "US",
            "UseQuic": "false",
            "Version": "2020-11-19",
            "appid": "1233",
            "device_platform": "android",
            "did": "7178618851310831146",
            "net_type": "wifi",
            "uid": info.user_id_str,
            "update_version_code": "2023001020",
            "version_code": "2023001020",
        },
        session=aioss,
    )

    upload_node = init_video_upload.Result.InnerUploadAddress.UploadNodes[0]
    store_info = upload_node.StoreInfos[0]

    delete_video_path = False
    if music_id:
        logger.debug("Replacing video audio")
        video = await replace_video_audio(video, music_id, aioss=aioss)
        if not video:
            logger.error("Error replacing video audio")
            return None
        delete_video_path = True

    await upload_file(
        host=upload_node.UploadHost,
        store_uri=store_info.StoreUri,
        space_key=store_info.Auth,
        uploadid=store_info.UploadID,
        file_path=video,
        aioss=aioss,
    )

    if delete_video_path:
        os.remove(video)

    commit_video_upload = await upload_action(
        host=keys.video_config.videoHostName,
        method="POST",
        access_key_id=keys.video_config.authorization2.access_key_id,
        access_key_secret=keys.video_config.authorization2.secret_access_key,
        amz_security_token=keys.video_config.authorization2.session_token,
        service_name="vod",
        params={
            "Action": "CommitUploadInner",
            "Region": "US",
            "SpaceName": "musical.ly",
            "StoreRegion": "US",
            "UseQuic": "false",
            "Version": "2020-11-19",
            "appid": "1233",
            "device_platform": "android",
            "did": "7178618851310831146",
            "net_type": "wifi",
            "uid": info.user_id_str,
            "update_version_code": "2023001020",
            "version_code": "2023001020",
        },
        payload={
            "Function": [{"Input": {"SnapshotTime": 0.9}, "Name": "Snapshot"}],
            "SessionKey": upload_node.SessionKey,
            "SuccessOids": [store_info.StoreUri],
        },
        session=aioss,
    )

    return commit_video_upload
