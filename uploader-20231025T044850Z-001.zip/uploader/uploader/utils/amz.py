"""This is all of the AWS (Amazon Web Services) header signing"""

import datetime
import hashlib
import hmac
from urllib import parse


__all__ = ("create_auth_header",)


def hash(key: bytes, msg: str):
    return hmac.new(key, msg.encode("utf-8"), hashlib.sha256).digest()


def create_signature_key(key: str, datestamp: str, region: str, service: str):
    keyDate = hash(("AWS4" + key).encode("utf-8"), datestamp)
    keyString = hash(keyDate, region)
    keyService = hash(keyString, service)
    keySigning = hash(keyService, "aws4_request")
    return keySigning


def create_auth_header(
    method: str,
    *,
    url: str,
    params: dict,
    access_key_id: str,
    access_key_secret: str,
    region: str = "sdwdmwlll",
    amz_security_token: str,
    service: str,
    date: datetime,
    payload: str = "",
) -> dict:
    # Create a date for headers and the credential string
    amz_date = date.strftime("%Y%m%dT%H%M%SZ")  # 2022
    date_stamp = date.strftime("%Y%m%d")  # Date w/o time, used in credential scope
    canonical_uri = parse.urlparse(url).path
    canonical_querystring = parse.urlencode(params)
    canonical_headers = ""

    signed_headers = {
        "x-amz-date": amz_date,
        "x-amz-security-token": amz_security_token,
    }

    for key, value in signed_headers.items():
        canonical_headers += f"{key}:{value}\n"
    signed_headers = ";".join(signed_headers.keys())
    payload_hash = hashlib.sha256(payload.encode("utf-8")).hexdigest()

    canonical_request = f"{method}\n{canonical_uri}\n{canonical_querystring}\n{canonical_headers}\n{signed_headers}\n{payload_hash}"

    algorithm = "AWS4-HMAC-SHA256"
    credential_scope = f"{date_stamp}/{region}/{service}/aws4_request"
    string_to_sign = f"{algorithm}\n{amz_date}\n{credential_scope}\n{hashlib.sha256(canonical_request.encode('utf-8')).hexdigest()}"

    signing_key = create_signature_key(access_key_secret, date_stamp, region, service)
    signature = hmac.new(
        signing_key, (string_to_sign).encode("utf-8"), hashlib.sha256
    ).hexdigest()

    authorization_header = f"{algorithm} Credential={access_key_id}/{credential_scope}, SignedHeaders={signed_headers}, Signature={signature}"

    return {
        "Authorization": authorization_header,
        "x-amz-date": amz_date,
        "x-amz-security-token": amz_security_token,
    }
