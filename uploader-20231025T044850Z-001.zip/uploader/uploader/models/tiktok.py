from enum import Enum
from pydantic import BaseModel

from typing import List, Optional, Union

__all__ = (
    "PassportAccountInfo",
    "AwemeTypes",
)


class AwemeTypes(Enum):
    VIDEO = "video"
    SLIDESHOW = "multi_photo"


class PassportAccountInfo(BaseModel):
    app_id: int
    avatar_url: str
    connects: List[str]
    country_code: int
    device_id: int
    email: str
    email_collected: bool
    has_password: int
    is_kids_mode: int
    mobile: str
    name: str
    need_verify: bool
    phone_collected: bool
    safe_verification_methods: Optional[List[str]]
    screen_name: str
    sec_user_id: str
    session_key: str
    user_create_time: int
    user_id: int
    user_id_str: str
    user_info_prompt: List[str]
    user_verified: bool
