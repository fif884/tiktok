"""These are the models for the uploade actions"""

from typing import Optional, List, Union
from pydantic import BaseModel, Field

__all__ = ("UploadResponse",)


class StoreInfo(BaseModel):
    StoreUri: str
    Auth: str
    UploadID: str
    UploadHeader: Optional[Union[str, dict]]


class UploadNode(BaseModel):
    Vid: Optional[str]
    Vids: Optional[List[str]]
    StoreInfos: List[StoreInfo]
    UploadHost: str
    UploadHeader: Optional[dict]
    Type: Optional[str]
    Protocol: Optional[str]
    SessionKey: str
    NodeConfig: Optional[dict]


class UploadAddressClass(BaseModel):
    StoreInfos: List[StoreInfo]
    UploadHosts: List[str]
    UploadHeader: Optional[str]
    SessionKey: str
    AdvanceOption: Optional[dict]


class InnerUploadAddressClass(BaseModel):
    UploadNodes: List[UploadNode]
    AdvanceOption: Optional[dict]


class ResponseMetadata(BaseModel):
    RequestId: str
    Action: str
    Version: str
    Service: str
    Region: str


class ImgResult(BaseModel):
    Uri: str
    UriStatus: int


class VideoMeta(BaseModel):
    Uri: str
    Bitrate: int
    Codec: str
    Duration: float
    FileType: str
    Format: str
    Height: int
    Md5: str
    OriginHeight: int
    OriginWidth: int
    Size: int
    Width: int


class VidResult(BaseModel):
    Vid: str
    VideoMeta: VideoMeta


class PluginResultClass(BaseModel):
    SourceUri: str
    FileName: str
    ImageUri: str
    ImageWidth: int
    ImageHeight: int
    ImageMd5: str
    ImageFormat: str
    ImageSize: int
    FrameCnt: int


class Result(BaseModel):
    UploadAddress: Optional[UploadAddressClass] = None
    InnerUploadAddress: Optional[InnerUploadAddressClass] = None
    RequestId: str
    SDKParam: Optional[dict] = None
    PluginResult: Optional[List[PluginResultClass]] = None
    # Results: Optional[List[ImgResult]] = None # NOTE this can be a list of ImgResult or VidResult
    Results: Optional[List[Union[ImgResult, VidResult]]] = None


class UploadResponse(BaseModel):
    ResponseMetadata: ResponseMetadata
    Result: Result
