from typing import List, Optional
from pydantic import BaseModel, validator


__all__ = (
    "Config",
    "Content",
)


class Schedule(BaseModel):
    when: List[dict]
    enabled: bool = True

    @validator("when")
    def when_is_not_empty(cls, v):
        if not v:
            raise ValueError("when cannot be empty")
        return v


class Config(BaseModel):
    do_slideshow_posts: bool
    do_video_posts: bool
    number_of_posts: Optional[int] = 1
    schedule: Schedule
    use_random_audio: bool
    shuffle_posts: bool
    private_mode: bool = False
    log_level: str = "INFO"


class Slideshow(BaseModel):
    audio_id: str
    description: str
    images: List[str]
    """images is a list of image paths"""


class Video(BaseModel):
    audio_id: str
    description: str
    video: str
    """video is a path to the video"""


class Content(BaseModel):
    slideshows: Optional[List[Slideshow]] = []
    videos: Optional[List[Video]] = []
