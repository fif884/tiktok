from pydantic import BaseModel, Field


__all__ = ("UploadAuthKeys",)


class Authorization2(BaseModel):
    access_key_id: str
    secret_access_key: str
    session_token: str
    space_name: str


class AudioConfig(BaseModel):
    appKey: str
    authorization2: Authorization2
    fileHostName: str
    fileRetryCount: int
    imageHostName: str
    maxFailTime: int
    maxFailTimeEnabled: bool
    rwTimeout: int
    socketNumber: int


class Extra(BaseModel):
    fatal_item_ids: list
    logid: str
    now: int


class CustomStickerConfig(BaseModel):
    appKey: str
    authorization2: Authorization2
    fileHostName: str
    fileRetryCount: int
    imageHostName: str
    maxFailTime: int
    maxFailTimeEnabled: bool
    rwTimeout: int
    socketNumber: int


class CustomStickerImageConfig(BaseModel):
    appKey: str
    authorization2: Authorization2
    fileHostName: str
    fileRetryCount: int
    imageHostName: str
    maxFailTime: int
    maxFailTimeEnabled: bool
    rwTimeout: int
    socketNumber: int


class ImgConfig(BaseModel):
    appKey: str
    authorization: str
    authorization2: Authorization2
    fileHostName: str
    fileRetryCount: int
    imageHostName: str
    maxFailTime: int
    maxFailTimeEnabled: bool
    rwTimeout: int
    socketNumber: int


class LogPb(BaseModel):
    impr_id: str


class MusicStripAudioConfig(BaseModel):
    app_key: str
    authorization2: Authorization2
    file_host_name: str
    file_retry_count: int
    max_fail_time: int
    rw_timeout: int
    socket_number: int


class PhotoUploadConfig(BaseModel):
    appKey: str
    authorization2: Authorization2
    fileHostName: str
    fileRetryCount: int
    imageHostName: str
    maxFailTime: int
    maxFailTimeEnabled: bool
    rwTimeout: int
    socketNumber: int


class RawPhotoUploadConfig(BaseModel):
    appKey: str
    authorization2: Authorization2
    fileRetryCount: int
    imageHostName: str
    maxFailTime: int
    maxFailTimeEnabled: bool
    rwTimeout: int
    socketNumber: int


class SettingsConfig(BaseModel):
    enable_pre_upload: int
    hw_encode_score: float
    pre_upload_encryption_mode: int
    publish_close_client_watermark: int
    sw_encode_score: float


class VFrameConfig(BaseModel):
    appKey: str
    authorization: str
    authorization2: Authorization2
    enableHttps: int
    fileHostName: str
    fileRetryCount: int
    imageHostName: str
    maxFailTime: int
    maxFailTimeEnabled: bool
    rwTimeout: int
    socketNumber: int
    userStoreRegion: str


class VideoConfig(BaseModel):
    aiCutAppKey: str
    aiCutAuthorization: str
    aiCutAuthorization2: Authorization2
    aliveMaxFailTime: int
    appKey: str
    authorization: str
    authorization2: Authorization2
    backupDNSParseType: int
    captionAppKey: str
    captionAuthorization: str
    captionAuthorization2: Authorization2
    coverTime: float
    data_flow_timeout: int
    enableExternDNS: int
    enableExternNet: int
    enableHttps: int
    enableMutitask: int
    enablePostMethod: int
    enableQuic: int
    enableTTNetDNS: int
    enable_client_network_judgement: bool
    enable_tt_uploader_ev_state: bool
    enable_tt_uploader_log_callback: bool
    fileHostName: str
    fileRetryCount: int
    fileTryHttpsEnable: bool
    is_stream_upload_enable: int
    mainDNSParseType: int
    maxFailTime: int
    maxFailTimeEnabled: bool
    maxFileSize: int
    openTimeOut: int
    sliceRetryCount: int
    sliceSize: int
    sliceTimeout: int
    socketNumber: int
    studio_refactored_file_upload_client_sdk: int
    testSpeedAppKey: str
    testSpeedAuthorization: str
    testSpeedAuthorization2: Authorization2
    ttnetConfigValue: int
    uploadRegion: str
    upload_backup_network_type: int
    upload_main_network_type: int
    upload_speed_test_threshold: int
    userStoreRegion: str
    videoHostName: str


class UploadAuthKeys(BaseModel):
    audio_config: AudioConfig
    custom_sticker_config: CustomStickerConfig
    custom_sticker_image_config: CustomStickerImageConfig
    extra: Extra
    img_config: ImgConfig
    log_pb: LogPb
    music_strip_audio_config: MusicStripAudioConfig
    photo_upload_config: PhotoUploadConfig
    raw_photo_upload_config: RawPhotoUploadConfig
    settings_config: SettingsConfig
    status_code: int
    status_msg: str
    vframe_config: VFrameConfig
    video_config: VideoConfig
