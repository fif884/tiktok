"""File the will sign TikTok requests"""

import hashlib
from time import time
from yarl._url import URL

from typing import List, Optional, Union

from urllib.parse import urlencode

from pydantic import BaseModel
from uploader.signer.argus import Argus
from uploader.signer.gorgon import Gorgon
from uploader.signer.ladon import Ladon


class SignRequest(BaseModel):
    url: URL
    headers: dict
    body: Optional[str]
    params: Optional[dict]

    class Config:
        arbitrary_types_allowed = True


DEFAULT_PARAMS = {
    "iid": "7293229938353850155",
    "device_id": "7293228832982795819",
    "ac": "wifi",
    "channel": "googleplay",
    "aid": "1233",
    "app_name": "musical_ly",
    "version_code": "300102",
    "version_name": "30.1.2",
    "device_platform": "android",
    "os": "android",
    "ab_version": "30.1.2",
    "ssmix": "a",
    "device_type": "Mi+MIX+3",
    "device_brand": "Xiaomi",
    "language": "en",
    "os_api": "30",
    "os_version": "11",
    "openudid": "05d5d9bf7c69ddb6",
    "manifest_version_code": "2023001020",
    "resolution": "1080*2208",
    "dpi": "440",
    "update_version_code": "2023001020",
    "_rticket": int(round((time() * 1000))),
    "app_type": "normal",
    "sys_region": "US",
    "timezone_name": "GMT",
    "app_language": "en",
    "ac2": "wifi",
    "uoo": "1",
    "op_region": "US",
    "timezone_offset": "0",
    "build_number": "30.1.2",
    "host_abi": "arm64-v8a",
    "locale": "en",
    "region": "US",
    "content_language": "en%2C",
    "ts": int(time()),
    "cdid": "65cca4b6-2119-4d48-a523-ae38baaae817",
}


def sign(
    params,
    payload: str or None = None,
    sec_device_id: str = "",
    cookie: str or None = None,
    aid: int = 1233,
    license_id: int = 1611921764,
    sdk_version_str: str = "v04.04.05-ov-android",
    sdk_version: int = 134744640,
    platform: int = 0,
    unix: int = None,
    gorgon_only: bool = False,
):
    x_ss_stub = (
        hashlib.md5(payload.encode("utf-8")).hexdigest() if payload != None else None
    )
    if not unix:
        unix = int(time())

    if gorgon_only:
        return Gorgon(params, unix, payload, cookie).get_value()

    return Gorgon(params, unix, payload, cookie).get_value() | {
        "x-ladon": Ladon.encrypt(unix, license_id, aid),
        "x-argus": Argus.get_sign(
            params,
            x_ss_stub,
            unix,
            platform=platform,
            aid=aid,
            license_id=license_id,
            sec_device_id=sec_device_id,
            sdk_version=sdk_version_str,
            sdk_version_int=sdk_version,
        ),
    }


def sign_request(
    url: str,
    *,
    cookies: List[str] = ["store-idc=useast5", "store-country-code=us"],
    params: dict = {},
    payload: Optional[Union[str, dict]] = None,
    add_headers: dict = {},
    gorgon_only: bool = False,
) -> SignRequest:
    if isinstance(payload, dict):
        payload = urlencode(payload)

    params = DEFAULT_PARAMS | params

    e_params = urlencode(params)

    cookies = "; ".join(cookies) if cookies is not None else cookies

    url = f"{url}?{e_params}"
    headers = sign(e_params, payload=payload, cookie=cookies, gorgon_only=gorgon_only) | {
        "user-agent": "com.zhiliaoapp.musically/2022506020 (Linux; U; Android 9; en_PL; vivo 1904; Build/PPR1.180610.011; Cronet/TTNetVersion:4cac2dc1 2022-07-06 QuicVersion:b67bcffb 2022-01-05)",
    }

    if cookies:
        headers["cookie"] = cookies

    headers.update(add_headers)

    return SignRequest(url=URL(url, encoded=True), headers=headers, body=payload, params=params)
