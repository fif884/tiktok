# https://rapidapi.com/yi005/api/tiktok-video-no-watermark2

import requests, time

def get_device(key: str, version: int, os: int):
    response = requests.get(
        url="https://tiktok-video-no-watermark2.p.rapidapi.com/service/registerDevice",
        headers={
            "X-RapidAPI-Key": key,
            "X-RapidAPI-Host": "tiktok-video-no-watermark2.p.rapidapi.com"
        },
        params={
            "aid": "1233",
            "version": version,
            "os": os,
            "idc": "useast5"
        }, 
        timeout=10
    )

    unprocessed = response.json()
    try:
        newDevice = unprocessed['data']['device_info']
    except KeyError as e:
        print(e)
        print('-----------------------------------')
        print(unprocessed)
    timestamps = {
        '_rticket': int(round((time.time() * 1000))),
        'ts': int(time.time()),
        'use_store_region_cookie': '1'
    }
    newDevice.update(timestamps)
    return newDevice
    
amount = int(input("Amount: "))

for _ in range(amount):
    device = get_device("02a34aacf9msh33b2ac2e5c4c554p1e34c9jsnb5af798e332b", version=290304, os=9)
    print(device)
    open("./output/devices.txt", "a+").write(f"{device}\n")